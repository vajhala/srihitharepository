package com.srihitha;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.srihitha.LoginDao.LoginDao;
import com.srihitha.RegisterDao.RegisterDao;
import com.srihitha.bean.Register;
import com.srihitha.bean.signupdetails;
import com.srihitha.login.Logindetail;

@Controller
public class MyController {
	@Autowired
	LoginDao dao;
	@Autowired
	RegisterDao dao2;
	
	
	@RequestMapping("Login")
	public ModelAndView callLoginPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LoginPage");
		return mv;
	}
	
	@RequestMapping("loginhere")
	public ModelAndView calllogin() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		return mv;
	}
	
	
	@RequestMapping("Home1")
	public ModelAndView callLogin12() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Home1");
		return mv;
		}
	@RequestMapping("Registration")
	public ModelAndView callLoginPage2() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Register");
		return mv;
		}
	@RequestMapping("InsertUser")
    public ModelAndView insertUserObject(Register register)
    {
        ModelAndView mv = new ModelAndView();

        //Insert
        dao2.save(register);
        mv.setViewName("Register");
        mv.addObject("msg","User Object Inserted");

        return mv;
    }
	@RequestMapping("LoginPage")
    public ModelAndView login(Register register) {
        ModelAndView mv = new ModelAndView();
        System.out.println("username="+register.getUserName());
        Optional<Register> obj = dao2.findById(register.getUserName());
        if(obj.isPresent()) {
            Register tmp=obj.get();
        if(tmp.getPassWord().equals(register.getPassWord())) {
           mv.setViewName("Home1");
        }
        else {
            mv.setViewName("Register");
            mv.addObject("msg", "Invalid Username/Password pls check your Username/Password");
        }
        }
        else {
            mv.setViewName("Register");
            mv.addObject("msg", "Invalid Username/Password pls check your Username/Password");
        }

        return mv;
    }
	
	}
