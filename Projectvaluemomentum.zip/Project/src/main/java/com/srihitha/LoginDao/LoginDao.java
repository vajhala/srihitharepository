package com.srihitha.LoginDao;

import org.springframework.data.repository.CrudRepository;

import com.srihitha.login.Logindetail;
import com.srihitha.login.Logindetail;

public interface LoginDao extends CrudRepository<Logindetail, Integer> {

}