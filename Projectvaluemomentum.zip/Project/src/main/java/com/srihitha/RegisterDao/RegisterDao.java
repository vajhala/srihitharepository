package com.srihitha.RegisterDao;

import org.springframework.data.repository.CrudRepository;

import com.srihitha.bean.Register;

public interface RegisterDao extends CrudRepository<Register, String> {


}